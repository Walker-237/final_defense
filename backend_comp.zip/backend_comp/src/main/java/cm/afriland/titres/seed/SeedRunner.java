package cm.afriland.titres.seed;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import cm.afriland.titres.config.AppProperties;
import cm.afriland.titres.security.PasswordService;
import cm.afriland.titres.security.Rbac;

/**
 * Initialisation de la base apres une reconstruction (volume Docker recree).
 *
 * Jeu de demonstration insere UNIQUEMENT sur base vide (reconstruction du volume) :
 * les 5 comptes utilisateurs de base, un compte-titres JOINT (titulaire +
 * co-signataire, pour la double signature) et 2 emissions PUBLIE (1 BTA, 1 OTA)
 * ouvertes a la souscription. Aucun ordre, dossier client supplementaire ni
 * entree d'audit n'est preinsere.
 *
 * En fonctionnement normal (redemarrage du backend sans wipe du volume), ce
 * runner se contente de constater que les utilisateurs existent deja et de
 * recharger la matrice RBAC en memoire.
 *
 * SECURITE : le mot de passe de demonstration n'est plus code en dur. Il est lu
 * depuis {@link AppProperties#getSeedDemoPassword()} (configurable via
 * application-{profile}.yml ou variable d'environnement). Par defense en
 * profondeur, ce runner refuse en outre de peupler la base si le profil actif
 * est "prod", meme si "seedOnStart" a ete laisse actif par erreur.
 */
@Component
public class SeedRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(SeedRunner.class);

    private static final String ROLE_CLIENT_PP = "CLIENT_PP";
    private static final String NOM_TANDJA = "TANDJA";

    private final JdbcTemplate jdbc;
    private final PasswordService password;
    private final AppProperties props;
    private final Rbac rbac;
    private final Environment environment;

    public SeedRunner(JdbcTemplate jdbc, PasswordService password, AppProperties props, Rbac rbac,
                      Environment environment) {
        this.jdbc = jdbc;
        this.password = password;
        this.props = props;
        this.rbac = rbac;
        this.environment = environment;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (props.isSeedOnStart()) {
            if (environment.acceptsProfiles(Profiles.of("prod"))) {
                log.warn("seedOnStart=true mais profil 'prod' actif — insertion des donnees "
                        + "de demonstration refusee par securite.");
            } else {
                String demoPassword = props.getSeedDemoPassword();
                if (!StringUtils.hasText(demoPassword)) {
                    throw new IllegalStateException(
                            "seedOnStart=true mais aucun mot de passe de demonstration configure "
                                    + "(propriete 'app.seed-demo-password' / variable d'environnement "
                                    + "correspondante). Insertion annulee.");
                }
                Long count = jdbc.queryForObject("SELECT count(*) FROM users", Long.class);
                if (count != null && count == 0) {
                    log.info("Base vide — insertion des comptes de demonstration "
                            + "(aucune autre donnee metier inseree).");
                    seedUsers(demoPassword);
                    seedJointAccount(demoPassword);
                    seedEmissions();
                    // Le mot de passe de demonstration n'est PAS journalise (secret).
                    log.info("Comptes de demonstration inseres (dont 1 compte-titres joint) "
                            + "+ 2 emissions PUBLIE de demo (1 BTA, 1 OTA).");
                } else {
                    log.info("Base deja peuplee ({} utilisateur(s)) — insertion ignoree.", count);
                }
            }
        }
        // Chargement de la matrice RBAC en memoire (table peuplee par la migration V5).
        rbac.loadMatrix();
    }

    /** Insere uniquement les 5 comptes de demonstration. */
    private void seedUsers(String demoPassword) {
        String hash = password.hash(demoPassword);
        // Colonnes : email, role, nom, prenom, compte_titres, compte_especes,
        //            solde, categorie, type_compte, telephone.
        // Le telephone des clients alimente l'indice de destination de l'OTP
        // (ecran de verification) et la supervision back-office.
        Object[][] seed = {
                {"jean.mballa@example.cm", ROLE_CLIENT_PP, "MBALLA", "Jean Paul",
                        "037 10001 00012345678", "037 10001 12345678901", 45_250_000L,
                        "NON_QUALIFIE", "INDIVIDUEL", "+237 699 123 678"},
                {"alucam@example.cm", "CLIENT_PM", "ALUCAM SA", null,
                        "037 10001 00045678912", "037 10001 45678912345", 2_340_000_000L,
                        "QUALIFIE", "INDIVIDUEL", "+237 677 456 912"},
                {"admin@afriland.cm", "ADMIN", "NDOMA", "Sandrine",
                        null, null, null, null, null, null},
                {"superviseur@afriland.cm", "SUPERVISEUR", "FOTSO", "Marie",
                        null, null, null, null, null, null},
                {"agent@afriland.cm", "AGENT", "BIYA", "Paul",
                        null, null, null, null, null, null},
        };
        for (Object[] u : seed) {
            jdbc.update(
                    "INSERT INTO users (email, password_hash, role, nom, prenom, compte_titres, "
                            + "compte_especes, solde, categorie, type_compte, telephone) "
                            + "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    u[0], hash, u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9]);
        }
    }

    /**
     * Compte-titres JOINT de demonstration : un titulaire principal et un
     * co-signataire, chacun avec SON login (mot de passe issu de la
     * configuration). Tout ordre passe sur ce compte requiert la double
     * signature. Facilite la demo sans dependre de l'envoi e-mail des
     * identifiants provisoires.
     */
    private void seedJointAccount(String demoPassword) {
        String hash = password.hash(demoPassword);

        // Titulaire principal (login + compte-titres partage).
        UUID primaryId = jdbc.queryForObject(
                "INSERT INTO users (email, password_hash, role, nom, prenom, compte_titres, "
                        + "compte_especes, solde, categorie, type_compte, telephone) "
                        + "VALUES (?,?,?,?,?,?,?,?,?,?,?) RETURNING id",
                UUID.class,
                "joint.titulaire@example.cm", hash, ROLE_CLIENT_PP, NOM_TANDJA, "Amadou",
                "037 10001 00099887766", "037 10001 99887766554", 25_000_000L,
                "NON_QUALIFIE", "JOINT", "+237 690 111 222");

        // Co-signataire : login propre, rattache au compte du titulaire principal.
        jdbc.update(
                "INSERT INTO users (email, password_hash, role, nom, prenom, telephone, account_holder_id) "
                        + "VALUES (?,?,?,?,?,?,?)",
                "joint.cosignataire@example.cm", hash, ROLE_CLIENT_PP, NOM_TANDJA, "Fatima",
                "+237 690 333 444", primaryId);

        // Dossier client (pour l'affichage back-office) + 1 sous-compte + signataires.
        jdbc.update("INSERT INTO client_profiles (user_id, type_personne, raison_sociale, compte_statut) "
                + "VALUES (?, 'PP', ?, 'ACTIF')", primaryId, "TANDJA Amadou & Fatima (compte joint)");
        jdbc.update("INSERT INTO sous_comptes_titres (user_id, numero, libelle, type, statut, "
                        + "date_ouverture, positions_count, valeur_totale, ordre) VALUES (?,?,?,?,?,?,?,?,?)",
                primaryId, "SC-JOINT-001", "Conservation principale", "CONSERVATION", "ACTIF",
                LocalDate.now(), 0, 0L, 0);
        jdbc.update("INSERT INTO client_contacts (user_id, type, nom, prenom, email, telephone_portable, ordre) "
                        + "VALUES (?, 'TITULAIRE', ?, ?, ?, ?, 0)",
                primaryId, NOM_TANDJA, "Amadou", "joint.titulaire@example.cm", "+237 690 111 222");
        jdbc.update("INSERT INTO client_contacts (user_id, type, nom, prenom, email, telephone_portable, ordre) "
                        + "VALUES (?, 'TITULAIRE', ?, ?, ?, ?, 1)",
                primaryId, NOM_TANDJA, "Fatima", "joint.cosignataire@example.cm", "+237 690 333 444");
    }

    /**
     * Deux emissions PUBLIE de demonstration (ouvertes a la souscription) : un BTA
     * (mode TAUX, sans coupon) et un OTA (mode PRIX, coupon annuel 7,50 %). Permet
     * de tester immediatement la souscription, l'adjudication, l'avis d'opere et le
     * parcours compte joint apres une reconstruction de la base.
     */
    private void seedEmissions() {
        UUID agentId = jdbc.queryForObject("SELECT id FROM users WHERE email = ?", UUID.class,
                "agent@afriland.cm");
        UUID supId = jdbc.queryForObject("SELECT id FROM users WHERE email = ?", UUID.class,
                "superviseur@afriland.cm");
        LocalDate today = LocalDate.now();
        OffsetDateTime now = OffsetDateTime.now();

        insertPublishedEmission(new EmissionSeed("BTA-CMR-DEMO", "CM0000DEMO01",
                        "BTA Cameroun 13 semaines (démo)", "BTA", "CMR", today, today.plusDays(91),
                        today.plusDays(2), 1_000_000L, 5_000_000_000L, 0.0, 1_000_000L, null, "TAUX"),
                agentId, supId, now);

        insertPublishedEmission(new EmissionSeed("OTA-GAB-DEMO", "GA0000DEMO02",
                        "OTA Gabon 4 ans 7,50% (démo)", "OTA", "GAB", today, today.plusYears(4),
                        today.plusDays(2), 10_000L, 10_000_000_000L, 7.5, 1_000_000L, "ANNUEL", "PRIX"),
                agentId, supId, now);
    }

    /** Regroupe les champs statiques d'une emission de demonstration. */
    private record EmissionSeed(
            String code, String isin, String libelle, String nature, String pays,
            LocalDate dateEmission, LocalDate dateEcheance, LocalDate dateReglement,
            long vnu, long montantGlobal, double taux, long montantMin,
            String freqCoupon, String mode) {
    }

    private void insertPublishedEmission(EmissionSeed e, UUID createdBy, UUID validatedBy, OffsetDateTime now) {
        int duree = (int) ChronoUnit.DAYS.between(e.dateEmission(), e.dateEcheance());
        jdbc.update("INSERT INTO emissions (code, isin, libelle, nature, pays_code, date_emission, "
                        + "ouverture_souscription, fermeture_souscription, date_echeance, date_reglement, "
                        + "duree_jours, valeur_nominale_unitaire, montant_global, taux_nominal, "
                        + "montant_minimum, frequence_coupon, mode_adjudication, status, created_by, "
                        + "validated_by, date_validation, observation) "
                        + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'PUBLIE', ?,?,?, 'NOUVELLE EMISSION')",
                e.code(), e.isin(), e.libelle(), e.nature(), e.pays(), e.dateEmission(),
                now, now.plusDays(30), e.dateEcheance(), e.dateReglement(), duree,
                e.vnu(), e.montantGlobal(), e.taux(), e.montantMin(), e.freqCoupon(), e.mode(),
                createdBy, validatedBy, now);
    }
}